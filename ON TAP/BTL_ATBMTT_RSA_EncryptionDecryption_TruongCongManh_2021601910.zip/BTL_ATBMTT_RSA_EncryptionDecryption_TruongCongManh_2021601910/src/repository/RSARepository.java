package repository;

public class RSARepository {

}
