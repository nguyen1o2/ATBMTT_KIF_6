/**
 * 
 */
/**
 * @author Admin
 *
 */
module BTL_ATBMTT_RSA_EncryptionDecryption_TruongCongManh_2021601910 {
	requires java.desktop;
}